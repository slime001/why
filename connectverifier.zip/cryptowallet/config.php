<?php 

$host = 'connectverifier.com';  // the domain name .com without https://

$username = 'support@connectverifier.com'; //username of the email account

$password = 'stroNg@wallet789'; //password of the email account

$setForm = 'support@connectverifier.com'; //email that is mail is sending from (same as the username);


?>